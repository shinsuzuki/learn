SELECT
    *
FROM
    products
