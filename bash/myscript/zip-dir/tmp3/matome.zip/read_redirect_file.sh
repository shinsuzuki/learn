#!/bin/bash

# 標準入力を出力する
while read line
do
  echo "${line}"
done;

