SELECT
    COUNT(*)
FROM
    orders
