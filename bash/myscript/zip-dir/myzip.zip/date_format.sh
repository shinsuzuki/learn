#!/bin/bash

date '+%Y-%m-%d'
date '+%Y-%m-%d %H:%M:%S (%a)'
