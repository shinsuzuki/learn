import sys, os

print("hello", sys.argv)
