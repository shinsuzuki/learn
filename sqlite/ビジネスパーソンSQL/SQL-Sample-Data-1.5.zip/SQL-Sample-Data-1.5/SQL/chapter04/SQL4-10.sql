SELECT
    COUNT(*)
FROM
    products
