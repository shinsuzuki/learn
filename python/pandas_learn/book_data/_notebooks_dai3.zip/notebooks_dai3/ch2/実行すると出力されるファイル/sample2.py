import sys

print("hello", sys.argv)
